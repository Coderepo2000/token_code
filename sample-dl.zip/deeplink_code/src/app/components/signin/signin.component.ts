import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AuthService } from '../../shared/auth.service';
import { Router,ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss'],
})
export class SigninComponent implements OnInit {
  signinForm: FormGroup;
  currentUser = {};
  constructor(
    private route: ActivatedRoute,
    public fb: FormBuilder,
    public authService: AuthService,
    public router: Router
  ) {
    this.signinForm = this.fb.group({
      email: [''],
      password: [''],
    });
  }
  ngOnInit() {
    
  }
  loginUser() {
    this.authService.signIn(this.signinForm.value).subscribe((res: any) => {
      localStorage.setItem('access_token', res.token);
      this.authService.getUserProfile(res._id).subscribe((res) => {
        this.currentUser = res;
        //this.router.navigate(['user-profile/' + res.msg._id]);
        const returnUrl = this.route.snapshot.queryParams['returnUrl'] || 'user-profile/' + res.msg._id;
        this.router.navigateByUrl(returnUrl);
      });
    });
  }
}